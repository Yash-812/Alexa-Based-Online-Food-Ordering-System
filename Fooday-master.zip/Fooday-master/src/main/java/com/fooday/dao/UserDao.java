package com.fooday.dao;

import java.util.List;

import com.fooday.model.RestaurantVo;
import com.fooday.model.UserRegisterVo;

public interface UserDao 
{
	public void Insert(UserRegisterVo uservo);
	
}
